export interface ITokenPayload {
  id: number;
  email: string;
  isAdmin: boolean;
}
