import { IAccount } from "./IAccount";

export interface IStore{
    account: IAccount | null;
}